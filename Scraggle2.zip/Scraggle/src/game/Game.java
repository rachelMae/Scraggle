/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;
import dictionary.Alphabet;
import dictionary.Dictionary;
import model.GridPoint;
import model.GridUnit;
/**
 *
 * @author Rachel
 */
//constructor
public class Game {
    
    private final GridUnit[][] grid; //grid variable
    
    public Game (Dictionary dictionary){
        
        this.grid = new GridUnit [4][4]; //initilazing grid
        this.populateGrid(); //fill in the grid
        
    }
    //getter
    public GridUnit[][] getGrid(){
        
        return grid;
    }
    //get grid unit method
    public GridUnit getGridUnit(GridPoint point){
        
        return grid[point.x][point.y];
    }
    //assign random letters into the grid
    private void populateGrid(){
        //loop though rows
        for(int i = 0; i < 4; i++){
            //loop through columns
            for(int j=0; j< 4; j++){
                //fill the grid spot
                grid[i][j] = new GridUnit(Alphabet.newRandom(), new GridPoint(i,j));
            }
        }
    }
    //prints out the grid selected
    public void displayGrid(){
        
        System.out.println("---------------");
        //loop through rows
        for(int i = 0; i < 4; i++){
            System.out.print("| ");
            //loop through columns
            for(int j=0; j< 4; j++){
                
                System.out.print(grid[i][j].getLetter());
                System.out.print(" |");
            }
            System.out.println("\n---------------"); //formatting
        }
    }
}
