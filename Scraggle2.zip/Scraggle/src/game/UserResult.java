/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.LinkedHashMap;
import java.util.Map;
import model.WordResult;

/**
 *
 * @author Rachel
 */
public class UserResult {
    
    private final Map<String, WordResult> wordToResultMap = new LinkedHashMap<>();
    private int totalScore = 0;
    
    //add method
    public void add(String word, WordResult result){
        this.wordToResultMap.put(word, result);
        this.totalScore += result.getScore();
    }
    //getter 
    public int getTotalScore(){
        
        return this.totalScore;
    }
   
    public WordResult get(String word){
        
        return this.wordToResultMap.get(word);
        
    }
    //all method
    public Map<String, WordResult> all(){
        return this.wordToResultMap;
    }
    //exists method
    public boolean exists(String word){
        return this.wordToResultMap.containsKey(word);
    }
    //get word count method
    public int getWordCount(){
        return this.wordToResultMap.size();
    }
}
