/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scraggle;

import dictionary.Dictionary;
import game.Game;


/**
 *
 * @author Rachel 
 */
public class Scraggle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // declare dictionary
        Dictionary dict = new Dictionary();
        Game game = new Game(dict);
        game.displayGrid();
        //mask
//        System.out.println("word search...........");
//        System.out.println(dict.search("mask"));
//        //silloutetee
//        System.out.println(dict.search("silhouette"));
//        //hourse
//        System.out.println(dict.search("horse"));
//        
//        System.out.println("prefix search..........");
//        //silho
//        System.out.println(dict.prefix("silho"));
//        //bir
//        System.out.println(dict.prefix("bir"));
    }
    
}
