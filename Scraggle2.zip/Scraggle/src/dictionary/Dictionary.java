/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionary;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Scanner;
/**
 *
 * @author Rachel
 */
public class Dictionary {
    
    //file
    private static final String WORDS_FILE = "words.txt";
    //member var class trie
    private final Trie tr;
    
    public Dictionary(){
        
        //scanner
        Scanner inputFile = null;
        String word; //declare string word
        
        //try catch block
        try{
         this.tr = new Trie();
         URL url = getClass().getResource(WORDS_FILE);
         File file = new File(url.toURI());
         
         //read input file
         inputFile = new Scanner (file);
         
         //check if null
         if(inputFile == null){
             throw new IOException("Invalid URL specifier");
         }
         //go through the whole file
         while(inputFile.hasNext() ){
             
             word = inputFile.next(); //read next word
             word = word.trim().toLowerCase(); //make the word lower case and trim
             tr.insert(word); //place word into trie
         }
        }
        //catch block for exceptions
        catch(IOException | URISyntaxException e){
            System.out.println("Error while loading words into trie");
            throw new RuntimeException(e);
        }
    }
    //return a search for the word
    public int search(String word){
       return this.tr.search(word);
    }
     
    //return a search for the prefix
    public boolean prefix(String word){
        return this.tr.prefix(word);
    }
    
}
